<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="Enemies" tilewidth="48" tileheight="40" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0" type="enemy_1">
  <image width="32" height="31" source="../vump-walk-0.png"/>
 </tile>
 <tile id="1" type="enemy_2">
  <image width="34" height="34" source="../ballbat-1.png"/>
 </tile>
 <tile id="2">
  <image width="48" height="40" source="../standvump-2.png"/>
 </tile>
</tileset>
