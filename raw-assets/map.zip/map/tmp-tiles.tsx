<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="tmp-tiles" tilewidth="16" tileheight="16" tilecount="80" columns="10">
 <image source="../../Vumpires/assets/images/temp-tiles.png" width="160" height="128"/>
 <tile id="50">
  <properties>
   <property name="cloud" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="cloud" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
